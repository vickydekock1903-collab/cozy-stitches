COZY STITCHES — UPDATED WEBSITE

This version:
- Uses the uploaded Cozy Stitches product photos.
- Uses "me/my" language for a one-person business.
- Has a more pink, girly and cute design.
- Uses Pacifico and Baloo 2 from Google Fonts for a curly/playful look.
- Includes 7 products: Crochet Doggie, Tigger, Eeyore, Winnie-the-Pooh, Piglet, Crochet Frog and Little Fairy.
- Prices: R320 each except the crochet frog at R160.
- Has no checkout, orders page, or special-request field.

IMPORTANT:
The contact form is visual only until it is connected to an email/form service.
